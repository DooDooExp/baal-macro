BAAL TRACKER - WINDOWS x64 PORTABLE EDITION

1. Extract the whole ZIP into a folder you can write to, such as Documents.
2. Keep BaalTracker.exe and the _internal folder together.
3. Double-click BaalTracker.exe. Python is included; no separate install is needed.
4. Close other tracker copies before using the macro. Join the verified GPO First Sea.
5. Check your fruit hotbar number and move keys in Abilities before starting.
6. Start with the button or F3. F3 toggles; F8 stops. Losing Roblox focus releases
   inputs; the run request stays active and resumes when Roblox regains focus.

If Roblox is running as administrator, run the tracker with matching privileges
using right-click > Run as administrator.

APPEARANCE
Open Appearance for hex/RGB colors, a color picker, background gradients,
Midnight/Graphite/Light palettes, font size, spacing, topmost and smooth scrolling.
Edits preview immediately. Save appearance keeps them without restarting farming.
Window transparency remains in Tracking. Apply & save keeps farming preferences.

CONFIGURATION
The bundle starts with the current farming settings, abilities and recorded routes.
Save/load general config and ability config separately from Overview / Abilities.
Internal JSON files remain writable in _internal, including appearance-settings.json.
Back up your configs and routes before replacing this folder with a newer release.

SERVER TRANSITIONS
Automatic recovery retains pending restarts while a joined server is loading.
If NPC reads are valid but no boss has been observed and portal data stays unknown,
the tracker retries another server after the larger of the data recovery timeout
and boss-wait timer (at least one second). This does not mark any boss defeated.
Automatic hopping must be enabled. Missing NPC data still prevents a false empty
server decision. Manual Stop/F8 and wrong-experience detection cancel automation.

COMPATIBILITY
This release includes the project's currently calibrated Roblox client version.
Update offsets fetches matching offsets; a different client build may also require
new Shift Lock, portal or server-menu calibration. An EXE does not remove those checks.

Downloaded offsets are saved in %LOCALAPPDATA%\BerryMacros\GPO\offsets.
The app creates this folder when needed and falls back to its bundled offsets
until an update is installed. An update error includes its failing stage.
Details are written to %LOCALAPPDATA%\BerryMacros\GPO\offset-update-error.log.
If reporting an update failure, send that log; remove private Windows user paths
before posting it publicly. Always extract the full ZIP before running the EXE.

SHARING
Share BaalTracker-Windows-x64.zip, not just the EXE: _internal is required.
In OneDrive: upload/select the ZIP > Share > link settings > Anyone with the link
(if available) > Can view. Leave downloads allowed, then Copy link.
The local file path is not an internet download link. No public upload is automatic.

The package excludes raw captures, inspection logs, screenshots and developer tools.
SHA256.txt beside the ZIP records the archive's checksum.
